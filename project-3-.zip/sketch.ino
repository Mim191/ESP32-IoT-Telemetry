
int counter = 0;

void setup() {
  Serial.begin(9600);

  // Set PB0-PB3 as OUTPUT and PB4 as INPUT
  DDRB = (DDRB & 0b11100000) | 0b00001111;

  // Enable internal pull-up resistor on PB4 (Pin 12)
  PORTB |= (1 << PB4);

  // Display initial value 0
  PORTB = (PORTB & 0b11110000) | (counter & 0x0F);
}

void loop() {

  // Check whether button is pressed
  if (!(PINB & (1 << PB4))) {

    delay(50);  // Debouncing

    // Confirm button is still pressed
    if (!(PINB & (1 << PB4))) {

      counter++;

      // Reset counter after 15
      if (counter > 15) {
        counter = 0;
      }

      // Display binary value using one PORTB write
      PORTB = (PORTB & 0b11110000) | (counter & 0x0F);

      Serial.println(counter);

      // Wait until button is released
      while (!(PINB & (1 << PB4))) {
      }

      delay(50);  // Release debouncing
    }
  }
}
