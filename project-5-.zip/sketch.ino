

#include <WiFi.h>
#include <DHT.h>

#define DHTPIN 15
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const int fanPin = 25;
const int btnPin = 4;

unsigned long previousMillis = 0;
const long interval = 2000;

bool manualOverride = false;
bool lastBtnState = HIGH;
bool lastStableState = HIGH;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 30;

void setup() {
  Serial.begin(115200);

  pinMode(fanPin, OUTPUT);
  pinMode(btnPin, INPUT_PULLUP);

  dht.begin();

  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");
}

void loop() {
  int reading = digitalRead(btnPin);

  if (reading != lastBtnState) {
    lastDebounceTime = millis();
  }

  if (millis() - lastDebounceTime > debounceDelay) {
    if (reading != lastStableState) {
      lastStableState = reading;

      if (lastStableState == LOW) {
        manualOverride = !manualOverride;

        digitalWrite(fanPin, manualOverride ? HIGH : LOW);

        Serial.print("Emergency Override! Fan: ");
        Serial.println(manualOverride ? "ON" : "OFF");
      }
    }
  }

  lastBtnState = reading;

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    float hum = dht.readHumidity();
    float temp = dht.readTemperature();

    if (isnan(hum) || isnan(temp)) {
      Serial.println("Failed to read from DHT sensor!");
    } else {
      Serial.print("Temperature: ");
      Serial.print(temp);
      Serial.print(" C | Humidity: ");
      Serial.print(hum);
      Serial.println(" %");

      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("Data published over WiFi successfully.");
      } else {
        Serial.println("WiFi disconnected. Reconnecting...");
        WiFi.reconnect();
      }
    }
  }
}
