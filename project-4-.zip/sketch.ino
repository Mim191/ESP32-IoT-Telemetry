
int speed = 300;

void setup() {

  // Set pins 4, 5, 6, 7 as OUTPUT
  DDRD |= B11110000;

  // Turn OFF all LEDs
  PORTD &= B00001111;

  // Start serial communication
  Serial.begin(9600);

  Serial.println("4 LED Scanner Started");
  Serial.print("New Speed: ");
  Serial.print(speed);
  Serial.println(" ms");
}

void loop() {

  // Forward direction: Pin 4 to Pin 7
  for (int i = 4; i <= 7; i++) {

    PORTD = (PORTD & B00001111) | (1 << i);

    delay(speed);

    checkSerial();
  }

  // Backward direction: Pin 6 to Pin 5
  for (int i = 6; i >= 5; i--) {

    PORTD = (PORTD & B00001111) | (1 << i);

    delay(speed);

    checkSerial();
  }
}

void checkSerial() {

  if (Serial.available() > 0) {

    char input = Serial.read();

    // Faster
    if (input == 'f' || input == 'F') {

      speed -= 50;

      if (speed < 50) {
        speed = 50;
      }

      Serial.print("New Speed: ");
      Serial.print(speed);
      Serial.println(" ms");
    }

    // Slower
    else if (input == 's' || input == 'S') {

      speed += 50;

      if (speed > 1000) {
        speed = 1000;
      }

      Serial.print("New Speed: ");
      Serial.print(speed);
      Serial.println(" ms");
    }
  }
}
