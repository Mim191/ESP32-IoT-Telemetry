
#include <WiFi.h>
#include <HTTPClient.h>
#include "soc/soc.h"
#include "soc/gpio_reg.h"

// Pin configuration
#define SENSOR_PIN 34
#define LED_PIN 2

// WiFi credentials
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// HTTP endpoint
const char* server = "http://httpbin.org/get?sensor=";

// Sensor reading
int sensorValue = 0;

// LED control using ESP32 registers
void ledON() {
  REG_WRITE(GPIO_OUT_W1TS_REG, (1UL << LED_PIN));
}

void ledOFF() {
  REG_WRITE(GPIO_OUT_W1TC_REG, (1UL << LED_PIN));
}

// Separate task for HTTP transmission
void httpTask(void *parameter) {

  for (;;) {

    if (WiFi.status() == WL_CONNECTED) {

      HTTPClient http;

      String url = String(server) + String(sensorValue);

      Serial.println("\nSending HTTP GET request...");
      
      ledON();

      http.begin(url);
      http.setTimeout(2000);

      int httpResponseCode = http.GET();

      if (httpResponseCode > 0) {
        Serial.print("HTTP Response Code: ");
        Serial.println(httpResponseCode);
      } 
      else {
        Serial.print("HTTP Error: ");
        Serial.println(http.errorToString(httpResponseCode));
      }

      http.end();

      ledOFF();

    } 
    else {
      Serial.println("WiFi disconnected!");
    }

    vTaskDelay(pdMS_TO_TICKS(3000));
  }
}

void setup() {

  Serial.begin(115200);

  // Configure sensor
  analogReadResolution(12);
  analogSetPinAttenuation(SENSOR_PIN, ADC_11db);

  // Configure LED
  pinMode(LED_PIN, OUTPUT);
  ledOFF();

  // Connect WiFi
  Serial.println("Connecting to WiFi...");

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  // Start HTTP task on Core 0
  xTaskCreatePinnedToCore(
    httpTask,
    "HTTP_Task",
    8192,
    NULL,
    1,
    NULL,
    0
  );
}

void loop() {

  // Continuously read analog sensor
  sensorValue = analogRead(SENSOR_PIN);

  Serial.print("Analog Sensor Value: ");
  Serial.println(sensorValue);

  delay(100);
}
