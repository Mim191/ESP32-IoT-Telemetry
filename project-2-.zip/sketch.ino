
#include <WiFi.h>
#include <PubSubClient.h>

#include "soc/soc.h"
#include "soc/gpio_reg.h"

// WiFi settings
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT settings
const char* mqtt_server = "broker.hivemq.com";
const char* topic = "myhome/esp32/control";

// MQTT client
WiFiClient espClient;
PubSubClient client(espClient);

// GPIO pins
#define BUTTON1 34
#define BUTTON2 27

#define LED1 25
#define LED2 26

// LED states
bool led1State = LOW;
bool led2State = LOW;

// Button variables
bool last1 = HIGH;
bool last2 = HIGH;

bool stable1 = HIGH;
bool stable2 = HIGH;

unsigned long time1 = 0;
unsigned long time2 = 0;

const unsigned long debounceDelay = 50;


// Control LEDs
void updateLED() {

  digitalWrite(LED1, led1State);
  digitalWrite(LED2, led2State);
}


// Receive MQTT message
void callback(char* topic, byte* payload,
              unsigned int length) {

  String msg = "";

  for (int i = 0; i < length; i++) {
    msg += (char)payload[i];
  }

  msg.trim();

  Serial.println(msg);

  if (msg == "ON") {

    led1State = HIGH;
    led2State = HIGH;
  }

  else if (msg == "OFF") {

    led1State = LOW;
    led2State = LOW;
  }

  updateLED();
}


// Connect WiFi
void connectWiFi() {

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);
    Serial.println("Connecting WiFi...");
  }

  Serial.println("WiFi Connected!");
}


// Connect MQTT
void connectMQTT() {

  while (!client.connected()) {

    if (client.connect("MyESP32Home")) {

      Serial.println("MQTT Connected!");

      client.subscribe(topic);
    }

    else {

      Serial.println("MQTT Failed!");

      delay(2000);
    }
  }
}


// Check physical button
void checkButton(
  bool reading,
  bool &lastReading,
  bool &stableState,
  unsigned long &lastTime,
  bool &ledState
) {

  if (reading != lastReading) {

    lastTime = millis();

    lastReading = reading;
  }

  if (millis() - lastTime > debounceDelay) {

    if (reading != stableState) {

      stableState = reading;

      if (stableState == LOW) {

        ledState = !ledState;

        updateLED();
      }
    }
  }
}


// Setup
void setup() {

  Serial.begin(115200);

  pinMode(BUTTON1, INPUT);
  pinMode(BUTTON2, INPUT_PULLUP);

  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);

  updateLED();

  connectWiFi();

  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}


// Main loop
void loop() {

  if (!client.connected()) {

    connectMQTT();
  }

  client.loop();


  // Read GPIO 34
  uint32_t value1 = REG_READ(GPIO_IN1_REG);

  bool button1 = (value1 >> 2) & 1;


  // Read GPIO 27
  uint32_t value2 = REG_READ(GPIO_IN_REG);

  bool button2 = (value2 >> 27) & 1;


  // Check buttons
  checkButton(
    button1, last1, stable1, time1, led1State
  );

  checkButton(
    button2, last2, stable2, time2, led2State
  );

}
